const selectableArea = document.querySelectorAll(".select-text-area");
const twitterSharBtn = document.getElementById("twitter-btn");
const tranBtn = document.getElementById("tran-btn");
const copyBtn = document.getElementById("copy-btn");




copyBtn.addEventListener("click" , copyBut);

  function copyBut(event){
   
    document.execCommand('copy');
    alert("Copied")
    
//  console.log("abrar")
      
  }

selectableArea.forEach(elem => {
    elem.addEventListener('mouseup', selectableTextAreaMouseUp);
  });


function selectableTextAreaMouseUp(event){
const selectedText = window.getSelection().toString().trim();
   if (selectedText.length){

    //    const x = event.pagex;
    //    const y = event.pageY;

    //   const twitterSharBtnWidth = Number(getComputedStyle(twitterSharBtn).width.slice(0,-2));
    //   const twitterSharBtnHeight = Number(getComputedStyle(twitterSharBtn).height.slice(0,-2));

    

    //  translate 
           tranBtn.style.left = `${50}px`;
           tranBtn.style.top =  `${210}px`;
           tranBtn.style.display = "block";
           tranBtn.classList.add("btnEnterance")

    // twitter
           twitterSharBtn.style.left = `${10}px`;
           twitterSharBtn.style.top =  `${210}px`;
           twitterSharBtn.style.display = "block";
           twitterSharBtn.classList.add("btnEnterance")

           //copy 
           copyBtn.style.left = `${150}px`;
           copyBtn.style.top =  `${210}px`;
           copyBtn.style.display = "block";
           copyBtn.classList.add("btnEnterance")


   }  
}


document.addEventListener("mousedown" , documentMouseDown);

function documentMouseDown (event){
    if (getComputedStyle(twitterSharBtn).display=="flex" && event.target.id!=="twitterSharBtn"){
        twitterSharBtn.style.display = "none";
        twitterSharBtn.classList.remove("btnEnterance")
    window.getSelection().empty();
    }

}

document.addEventListener("mousedown" , documentMouseDown);

function documentMouseDown (event){
    if (getComputedStyle(tranBtn).display=="flex" && event.target.id!=="tranBtn"){
        tranBtn.style.display = "none";
        tranBtn.classList.remove("btnEnterance")
    window.getSelection().empty();
    }

}


document.addEventListener("mousedown" , documentMouseDown);

function documentMouseDown (event){
    if (getComputedStyle(copyBtn).display=="flex" && event.target.id!=="copyBtn"){
        copyBtn.style.display = "none";
        copyBtn.classList.remove("btnEnterance")
    window.getSelection().empty();
    }

}


twitterSharBtn.addEventListener("click" , twitterSharBtnClick);

function twitterSharBtnClick(event){

    const twitterSharUrl = "https://twitter.com/intent/tweet";
    const text = window.getSelection().toString().trim();
  
    window.open(`${twitterSharUrl}?text="${text}"`);

}



tranBtn.addEventListener("click" , tranBtnClick);

function tranBtnClick(event){

    const translateUrl = "https://translate.google.com/?hl=ar&tab=TT";
    const text = window.getSelection().toString().trim();
    
    window.open(`${translateUrl}?text="${text}"`);
  

    

}
